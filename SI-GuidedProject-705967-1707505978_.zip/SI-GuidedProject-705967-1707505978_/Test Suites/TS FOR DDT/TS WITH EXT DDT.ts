<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS WITH EXT DDT</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c93dcdab-c8cc-421f-88b4-66be97d24798</testSuiteGuid>
   <testCaseLink>
      <guid>048b42e9-5336-4efa-959b-101465880cde</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_MAKE_APPOINTMENT_001/MAKE_APPOINTMENT</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>63805a1e-0154-426f-8c96-e599e775b7ce</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT FOR EXT DATA/DDT EXT DATA_001</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>63805a1e-0154-426f-8c96-e599e775b7ce</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>VARIABLE</value>
         <variableId>bc6534fc-9ec2-4b4d-b9b4-94923a14fd6e</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
